
Hope Platform — Static demo site (for Vercel deploy)
==================================================

این پروژه یک وب‌سایت نمونهٔ استاتیک است که می‌توانید مستقیم در Vercel آپلود و نمایش دهید.  
هدف: ارائهٔ یک نسخهٔ کلی، قابل کلیک و آمادهٔ نمایش برای سرمایه‌گذاران با تصاویر واقعی از Unsplash.

فایل‌ها:
- index.html — صفحهٔ اصلی
- product.html — صفحهٔ فروشگاه/محصول
- artisan.html — صفحهٔ بافندگان
- styles.css — استایل‌ها
- script.js — تعاملات ساده

عکس‌ها از Unsplash انتخاب شده‌اند (رایگان برای استفادهٔ تجاری). چند تصویر مرجع:
- weaving / loom photos: https://unsplash.com/s/photos/weaving -- نمونه‌ها استفاده‌شده در سایت.
- interior / living room photos (Dubai): https://unsplash.com/s/photos/living-room
- vancouver skyline: https://unsplash.com/s/photos/vancouver-skyline
(برای لیست دقیق تصاویر به نتایج سرچ Unsplash مراجعه کنید.)

نصب و دیپلوی در Vercel:
1. فایل‌های داخل این فولدر را در یک مخزن Git جدید قرار دهید (GitHub/GitLab).  
2. به https://vercel.com برید و با GitHub متصل شوید.  
3. New Project → Import from GitHub → انتخاب ریپو → Deploy.  
   - پروژه استاتیک است؛ Vercel به‌صورت خودکار آن‌را منتشر می‌کند.
4. اگر می‌خواهید تصاویر محلی درون repo ذخیره شود، تصاویر Unsplash را دانلود کرده و در پوشهٔ /public قرار دهید و آدرس src ها را اصلاح کنید.

حقوق استفاده از تصاویر:
- تصاویر از Unsplash استفاده شده‌اند که معمولاً برای استفاده تجاری آزاد هستند، اما لطفاً قوانین Unsplash را بررسی کنید و در صورت نیاز عکاس را در پیوست crédits ذکر کنید.

محل خروجی zip و فایل‌ها:
- فایل zip تولید شده: /mnt/data/hopeplatform_vercel_site.zip
